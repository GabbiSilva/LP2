﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.bttverificadesc = new System.Windows.Forms.Button();
            this.rabutF = new System.Windows.Forms.RadioButton();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rabutM = new System.Windows.Forms.RadioButton();
            this.upfilhos = new System.Windows.Forms.NumericUpDown();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rabutCasado = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblDados = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtsalbruto = new System.Windows.Forms.TextBox();
            this.txtsalliquido = new System.Windows.Forms.TextBox();
            this.txtdescontoINSS = new System.Windows.Forms.TextBox();
            this.txtsalfamilia = new System.Windows.Forms.TextBox();
            this.txtINSS = new System.Windows.Forms.TextBox();
            this.txtdescontoIRPF = new System.Windows.Forms.TextBox();
            this.txtIRPF = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.upfilhos)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome Funcionario";
            // 
            // bttverificadesc
            // 
            this.bttverificadesc.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttverificadesc.Location = new System.Drawing.Point(21, 167);
            this.bttverificadesc.Name = "bttverificadesc";
            this.bttverificadesc.Size = new System.Drawing.Size(416, 66);
            this.bttverificadesc.TabIndex = 1;
            this.bttverificadesc.Text = "Verifica Desconto";
            this.bttverificadesc.UseVisualStyleBackColor = true;
            this.bttverificadesc.Click += new System.EventHandler(this.bttverificadesc_Click);
            // 
            // rabutF
            // 
            this.rabutF.AutoSize = true;
            this.rabutF.Checked = true;
            this.rabutF.Location = new System.Drawing.Point(6, 36);
            this.rabutF.Name = "rabutF";
            this.rabutF.Size = new System.Drawing.Size(38, 27);
            this.rabutF.TabIndex = 2;
            this.rabutF.TabStop = true;
            this.rabutF.Text = "F";
            this.rabutF.UseVisualStyleBackColor = true;
            // 
            // txtnome
            // 
            this.txtnome.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnome.Location = new System.Drawing.Point(185, 25);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(252, 30);
            this.txtnome.TabIndex = 4;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rabutM);
            this.groupBox1.Controls.Add(this.rabutF);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(21, 246);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SEXO";
            // 
            // rabutM
            // 
            this.rabutM.AutoSize = true;
            this.rabutM.Location = new System.Drawing.Point(6, 64);
            this.rabutM.Name = "rabutM";
            this.rabutM.Size = new System.Drawing.Size(43, 27);
            this.rabutM.TabIndex = 3;
            this.rabutM.Text = "M";
            this.rabutM.UseVisualStyleBackColor = true;
            // 
            // upfilhos
            // 
            this.upfilhos.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.upfilhos.Location = new System.Drawing.Point(185, 112);
            this.upfilhos.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.upfilhos.Name = "upfilhos";
            this.upfilhos.Size = new System.Drawing.Size(252, 30);
            this.upfilhos.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rabutCasado);
            this.panel1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(240, 259);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(197, 87);
            this.panel1.TabIndex = 7;
            // 
            // rabutCasado
            // 
            this.rabutCasado.AutoSize = true;
            this.rabutCasado.Location = new System.Drawing.Point(52, 26);
            this.rabutCasado.Name = "rabutCasado";
            this.rabutCasado.Size = new System.Drawing.Size(89, 27);
            this.rabutCasado.TabIndex = 8;
            this.rabutCasado.Text = "Casado";
            this.rabutCasado.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 23);
            this.label2.TabIndex = 9;
            this.label2.Text = "Salário Bruto";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 23);
            this.label3.TabIndex = 10;
            this.label3.Text = "Número de Filhos";
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Font = new System.Drawing.Font("Tahoma", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDados.Location = new System.Drawing.Point(17, 380);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(102, 27);
            this.lblDados.TabIndex = 11;
            this.lblDados.Text = "lbl Dados";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(473, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 23);
            this.label5.TabIndex = 12;
            this.label5.Text = "Aliquota INSS";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(476, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 23);
            this.label6.TabIndex = 13;
            this.label6.Text = "Aliquota IRPF";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(473, 139);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 23);
            this.label7.TabIndex = 14;
            this.label7.Text = "Salário Familia";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(473, 191);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(132, 23);
            this.label8.TabIndex = 15;
            this.label8.Text = "Salário Liquido";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(473, 287);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(132, 23);
            this.label10.TabIndex = 17;
            this.label10.Text = "Desconto IRPF";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(473, 238);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(135, 23);
            this.label11.TabIndex = 18;
            this.label11.Text = "Desconto INSS";
            // 
            // txtsalbruto
            // 
            this.txtsalbruto.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalbruto.Location = new System.Drawing.Point(185, 69);
            this.txtsalbruto.Name = "txtsalbruto";
            this.txtsalbruto.Size = new System.Drawing.Size(252, 30);
            this.txtsalbruto.TabIndex = 19;
            // 
            // txtsalliquido
            // 
            this.txtsalliquido.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalliquido.Location = new System.Drawing.Point(619, 186);
            this.txtsalliquido.Name = "txtsalliquido";
            this.txtsalliquido.ReadOnly = true;
            this.txtsalliquido.Size = new System.Drawing.Size(169, 30);
            this.txtsalliquido.TabIndex = 20;
            // 
            // txtdescontoINSS
            // 
            this.txtdescontoINSS.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdescontoINSS.Location = new System.Drawing.Point(619, 234);
            this.txtdescontoINSS.Name = "txtdescontoINSS";
            this.txtdescontoINSS.ReadOnly = true;
            this.txtdescontoINSS.Size = new System.Drawing.Size(169, 30);
            this.txtdescontoINSS.TabIndex = 21;
            // 
            // txtsalfamilia
            // 
            this.txtsalfamilia.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalfamilia.Location = new System.Drawing.Point(619, 135);
            this.txtsalfamilia.Name = "txtsalfamilia";
            this.txtsalfamilia.ReadOnly = true;
            this.txtsalfamilia.Size = new System.Drawing.Size(169, 30);
            this.txtsalfamilia.TabIndex = 22;
            // 
            // txtINSS
            // 
            this.txtINSS.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtINSS.Location = new System.Drawing.Point(619, 32);
            this.txtINSS.Name = "txtINSS";
            this.txtINSS.ReadOnly = true;
            this.txtINSS.Size = new System.Drawing.Size(169, 30);
            this.txtINSS.TabIndex = 23;
            // 
            // txtdescontoIRPF
            // 
            this.txtdescontoIRPF.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdescontoIRPF.Location = new System.Drawing.Point(619, 283);
            this.txtdescontoIRPF.Name = "txtdescontoIRPF";
            this.txtdescontoIRPF.ReadOnly = true;
            this.txtdescontoIRPF.Size = new System.Drawing.Size(169, 30);
            this.txtdescontoIRPF.TabIndex = 24;
            // 
            // txtIRPF
            // 
            this.txtIRPF.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIRPF.Location = new System.Drawing.Point(619, 83);
            this.txtIRPF.Name = "txtIRPF";
            this.txtIRPF.ReadOnly = true;
            this.txtIRPF.Size = new System.Drawing.Size(169, 30);
            this.txtIRPF.TabIndex = 25;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(816, 450);
            this.Controls.Add(this.txtIRPF);
            this.Controls.Add(this.txtdescontoIRPF);
            this.Controls.Add(this.txtINSS);
            this.Controls.Add(this.txtsalfamilia);
            this.Controls.Add(this.txtdescontoINSS);
            this.Controls.Add(this.txtsalliquido);
            this.Controls.Add(this.txtsalbruto);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.upfilhos);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.bttverificadesc);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.upfilhos)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bttverificadesc;
        private System.Windows.Forms.RadioButton rabutF;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown upfilhos;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox rabutCasado;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtsalbruto;
        private System.Windows.Forms.TextBox txtsalliquido;
        private System.Windows.Forms.TextBox txtdescontoINSS;
        private System.Windows.Forms.TextBox txtsalfamilia;
        private System.Windows.Forms.TextBox txtINSS;
        private System.Windows.Forms.TextBox txtdescontoIRPF;
        private System.Windows.Forms.TextBox txtIRPF;
        private System.Windows.Forms.RadioButton rabutM;
    }
}

