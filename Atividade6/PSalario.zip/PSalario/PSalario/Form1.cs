﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
       
     

        private void bttverificadesc_Click(object sender, EventArgs e)
        {
            double SalarioBruto = 0;
            double SalarioLiquido = 0;
            double NumeroFilhos = 0;
            double SalarioFamilia = 0;
            double DescontoINSS = 0;
            double DescontoIRPF = 0;
            string Dados;
            string Nome = Convert.ToString(txtnome);

            if (!double.TryParse(txtsalbruto.Text, out SalarioBruto) || !double.TryParse(upfilhos.Text, out NumeroFilhos))
                MessageBox.Show("Salário Errado e Número de filhos devem ser numéricos!");
            else
            {
                if (SalarioBruto <= 0)
                    MessageBox.Show("Salário bruto deve ser maior que 0");
                else
                {
                    if (SalarioBruto <= 800.47)
                    {
                        txtINSS.Text = "7,65%";
                        DescontoINSS = 0.0765 * SalarioBruto;
                    }
                    else if (SalarioBruto <= 1050)
                    {
                        txtINSS.Text = "8,65%";
                        DescontoINSS = ((8.65 / 100) * SalarioBruto);
                    }
                    if (SalarioBruto <= 1400.77)
                    {
                        txtINSS.Text = "9,00%";
                        DescontoINSS = ((9.00 / 100) * SalarioBruto);
                    }
                    else if (SalarioBruto <= 2801.56)
                    {
                        txtINSS.Text = "11,00%";
                        DescontoINSS = 0.11 * SalarioBruto;
                    }
                    else
                    {
                        txtINSS.Text = " Teto";
                        DescontoINSS = 308.17;
                    }

                    txtdescontoINSS.Text = DescontoINSS.ToString("N2");

                    if (SalarioBruto <= 1257.12)
                    {
                        txtIRPF.Text = "Isento";
                    }

                    else if (SalarioBruto <= 2512.08)
                    {
                        txtIRPF.Text = "15%";
                        DescontoIRPF = (SalarioBruto * 185 / 100);
                    }

                    else
                    {
                        txtIRPF.Text = "27,5%";
                        DescontoIRPF = (SalarioBruto * 27.5 / 100);
                    }
                    txtdescontoIRPF.Text = DescontoIRPF.ToString("N2");

                    if (NumeroFilhos >0)
                    {
                        if (SalarioBruto <= 435.52)
                        {
                            SalarioFamilia = (NumeroFilhos * 22.33);
                        }
                        
                        else if (SalarioBruto <= 654.61)
                        {
                            SalarioFamilia = (NumeroFilhos * 15.74);
                        }

                        txtsalfamilia.Text = SalarioFamilia.ToString("N2");
                        SalarioLiquido = SalarioBruto + SalarioFamilia - DescontoINSS - DescontoIRPF;
                        txtsalliquido.Text = SalarioLiquido.ToString("N2");

                        

                      Dados = (rabutF) ? "O salario da Sra " + Nome + ((rabutCasado) ? "que é casado " +
                              ((NumeroFilhos > 0) ? (" e tem " + NumeroFilhos + "filhos é " + SalarioLiquido)) : 
                              ("sem filhos é" + SalarioLiquido)) : (NumeroFilhos > 0) ? ("que é solteira e tem " + NumeroFilhos + "filhos é " + SalarioLiquido) : 
                              ("que é solteira, sem filhos é" + SalarioLiquido) : (rabutM) ? "O salario do Sr " + Nome + (rabutCasado ? "que é casado " +
                              ((NumeroFilhos > 0) ? (" e tem " + NumeroFilhos + "filhos é " + SalarioLiquido)) :
                              ("sem filhos é" + SalarioLiquido)) : (NumeroFilhos > 0) ? ("que é solteiro e tem " + NumeroFilhos + "filhos é " + SalarioLiquido) :
                              ("que é solteiro, sem filhos é" + SalarioLiquido);

                       lblDados.Text = Dados;
                    }
                    
                }
                
                    
                
            }


        }
    }

}
   