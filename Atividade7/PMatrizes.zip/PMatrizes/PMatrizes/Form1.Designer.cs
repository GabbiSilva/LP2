﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInverteVetor = new System.Windows.Forms.Button();
            this.btnMercadoria = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnNome = new System.Windows.Forms.Button();
            this.btnTotal = new System.Windows.Forms.Button();
            this.btnArray = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInverteVetor
            // 
            this.btnInverteVetor.Font = new System.Drawing.Font("Britannic Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInverteVetor.Location = new System.Drawing.Point(10, 12);
            this.btnInverteVetor.Name = "btnInverteVetor";
            this.btnInverteVetor.Size = new System.Drawing.Size(242, 183);
            this.btnInverteVetor.TabIndex = 0;
            this.btnInverteVetor.Text = "Carrega vetor e os inverte";
            this.btnInverteVetor.UseVisualStyleBackColor = true;
            this.btnInverteVetor.Click += new System.EventHandler(this.btnInverteVetor_Click);
            // 
            // btnMercadoria
            // 
            this.btnMercadoria.Font = new System.Drawing.Font("Britannic Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMercadoria.Location = new System.Drawing.Point(278, 12);
            this.btnMercadoria.Name = "btnMercadoria";
            this.btnMercadoria.Size = new System.Drawing.Size(242, 183);
            this.btnMercadoria.TabIndex = 1;
            this.btnMercadoria.Text = "Ler dados das Mercadorias";
            this.btnMercadoria.UseVisualStyleBackColor = true;
            this.btnMercadoria.Click += new System.EventHandler(this.btnMercadoria_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Font = new System.Drawing.Font("Britannic Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedia.Location = new System.Drawing.Point(278, 214);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(242, 183);
            this.btnMedia.TabIndex = 2;
            this.btnMedia.Text = "Média Alunos";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnNome
            // 
            this.btnNome.Font = new System.Drawing.Font("Britannic Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNome.Location = new System.Drawing.Point(542, 12);
            this.btnNome.Name = "btnNome";
            this.btnNome.Size = new System.Drawing.Size(242, 183);
            this.btnNome.TabIndex = 5;
            this.btnNome.Text = "Nomes das Pessoas";
            this.btnNome.UseVisualStyleBackColor = true;
            this.btnNome.Click += new System.EventHandler(this.btnNome_Click);
            // 
            // btnTotal
            // 
            this.btnTotal.Font = new System.Drawing.Font("Britannic Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotal.Location = new System.Drawing.Point(542, 214);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(242, 183);
            this.btnTotal.TabIndex = 4;
            this.btnTotal.Text = "Variavel Total";
            this.btnTotal.UseVisualStyleBackColor = true;
            // 
            // btnArray
            // 
            this.btnArray.Font = new System.Drawing.Font("Britannic Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArray.Location = new System.Drawing.Point(10, 214);
            this.btnArray.Name = "btnArray";
            this.btnArray.Size = new System.Drawing.Size(242, 183);
            this.btnArray.TabIndex = 3;
            this.btnArray.Text = "ArrayList";
            this.btnArray.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 413);
            this.Controls.Add(this.btnNome);
            this.Controls.Add(this.btnTotal);
            this.Controls.Add(this.btnArray);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnMercadoria);
            this.Controls.Add(this.btnInverteVetor);
            this.Name = "Form1";
            this.Text = "/.0";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnInverteVetor;
        private System.Windows.Forms.Button btnMercadoria;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnNome;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Button btnArray;
    }
}

