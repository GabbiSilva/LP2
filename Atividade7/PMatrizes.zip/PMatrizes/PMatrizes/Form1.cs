﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInverteVetor_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;
            string saida = "";

            for (var i = 0; 0 <= 19; i++)
            {
                auxiliar = Interaction.InputBox("Digite um número", "Entrada de dados"); //primeiro vai ser a escrita de dentro da caixinha e a segunda o titulo da caixinha
                if (!int.TryParse(auxiliar, out vetor[i])) // Para transformar a variavel "String" em int e esta validando os dados
                {
                    MessageBox.Show("Valor Inválido!");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida; // revertendo os valores
                }

                MessageBox.Show(saida);
            }

            /*Reverse para reverter os numeros do vetor
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
            {
                auxiliar += x + "\n";
            }

            MessageBox.Show(auxiliar);

            //for para reverter os numeros
            auxiliar = ""; //Limpar a variavel
            for (var i = 19 ; i >= 0; i-- )
            {
                auxiliar += "\n" + vetor[i];
            }
            MessageBox.Show("auxiliar"); */

        }

        private void btnMercadoria_Click(object sender, EventArgs e)
        {
            double[] quantidade = new double[10];
            double[] preco = new double[10];
            string auxiliar;
            double faturamento = 0;

            for (var i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade da mercadoria " + (i + 1), "Entrada das Quantidades");
                if (!double.TryParse(auxiliar, out quantidade[i]))
                {
                    MessageBox.Show("Quantidade Inválida!");
                    i--;
                }
                else
                {
                    while (preco[i] <= 0)
                    {
                        auxiliar = Interaction.InputBox("Digite o preço da mercadoria " + (i + 1), "Entrada dos Preços");
                        if (!double.TryParse(auxiliar, out preco[i]))
                        {
                            MessageBox.Show("Preço Inválido!");
                        }
                        else
                        {
                            if (preco[i] <= 0)
                            {
                                MessageBox.Show("Preço deve ser maior que zero!");
                            }
                        }
                    }

                    faturamento += quantidade[i] * preco[i];
                }
            }
            MessageBox.Show("Faturamento:" + faturamento.ToString("N2"));
        }

        private void btnNome_Click(object sender, EventArgs e)
        {
            string[] Nomes = new string[1];
            string auxiliar; 

            auxiliar = Interaction.InputBox("Digite o nome completo ");

            if (!double.TryParse(auxiliar, out Nomes[0]));
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            double media = 0;
            double[,] Notas = new double[20,3];
            int i, j;
            string auxiliar;

            for( i = 0; i < 20; i++)
                for(  j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota " + (j+1) + " do aluno" + (i+1));
                    if (!double.TryParse(auxiliar, out Notas[i, j]))
                {
                    MessageBox.Show("Nota deverá ser entre 0 e 10!");
                    j--;
                }
                    else
                    {
                        if ( Notas[i,j] <= 0 || Notas[i,j] >= 10)
                        {
                            MessageBox.Show("Nota deverá ser entre 0 e 10!");
                            j--;
                        }

                        media +=  Notas[i, j];
                    }
                      
                }
            media = media / 3;
            MessageBox.Show("Media: " + media.ToString("N2"));
        }
    }
}
