﻿namespace PMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btniguais = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnasteriscos = new System.Windows.Forms.Button();
            this.btninserirtexto = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btniguais
            // 
            this.btniguais.Font = new System.Drawing.Font("Segoe Marker", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btniguais.Location = new System.Drawing.Point(32, 127);
            this.btniguais.Name = "btniguais";
            this.btniguais.Size = new System.Drawing.Size(158, 76);
            this.btniguais.TabIndex = 0;
            this.btniguais.Text = "Testar Iguais";
            this.btniguais.UseVisualStyleBackColor = true;
            this.btniguais.Click += new System.EventHandler(this.btniguais_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe Marker", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "Palavra 1";
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Font = new System.Drawing.Font("Segoe Marker", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpalavra1.Location = new System.Drawing.Point(130, 12);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(272, 30);
            this.txtpalavra1.TabIndex = 2;
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Font = new System.Drawing.Font("Segoe Marker", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpalavra2.Location = new System.Drawing.Point(130, 73);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(272, 30);
            this.txtpalavra2.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe Marker", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 22);
            this.label2.TabIndex = 3;
            this.label2.Text = "Palavra 2";
            // 
            // btnasteriscos
            // 
            this.btnasteriscos.Font = new System.Drawing.Font("Segoe Marker", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnasteriscos.Location = new System.Drawing.Point(130, 228);
            this.btnasteriscos.Name = "btnasteriscos";
            this.btnasteriscos.Size = new System.Drawing.Size(161, 76);
            this.btnasteriscos.TabIndex = 7;
            this.btnasteriscos.Text = "Inserir Asteriscos no Texto 1";
            this.btnasteriscos.UseVisualStyleBackColor = true;
            this.btnasteriscos.Click += new System.EventHandler(this.btnasteriscos_Click);
            // 
            // btninserirtexto
            // 
            this.btninserirtexto.Font = new System.Drawing.Font("Segoe Marker", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninserirtexto.Location = new System.Drawing.Point(226, 127);
            this.btninserirtexto.Name = "btninserirtexto";
            this.btninserirtexto.Size = new System.Drawing.Size(176, 76);
            this.btninserirtexto.TabIndex = 8;
            this.btninserirtexto.Text = "Inserir Texto 1 no Texto 2";
            this.btninserirtexto.UseVisualStyleBackColor = true;
            this.btninserirtexto.Click += new System.EventHandler(this.btninserirtexto_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(437, 492);
            this.Controls.Add(this.btninserirtexto);
            this.Controls.Add(this.btnasteriscos);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btniguais);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btniguais;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnasteriscos;
        private System.Windows.Forms.Button btninserirtexto;
    }
}