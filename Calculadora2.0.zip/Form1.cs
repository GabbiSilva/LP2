﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        decimal v1, v2;
        string operacao = "";

        private void b7_Click(object sender, EventArgs e)
        {
            textBoxRes.Text = textBoxRes.Text + "7";
        }

        private void b8_Click(object sender, EventArgs e)
        {
            textBoxRes.Text += "8";
        }

        private void b9_Click(object sender, EventArgs e)
        {
            textBoxRes.Text += "9";
        }

        private void b4_Click(object sender, EventArgs e)
        {
            textBoxRes.Text += "4";
        }

        private void b5_Click(object sender, EventArgs e)
        {
            textBoxRes.Text += "5";
        }

        private void b6_Click(object sender, EventArgs e)
        {
            textBoxRes.Text += "6";
        }

        private void b1_Click(object sender, EventArgs e)
        {
            textBoxRes.Text += "1";
        }

        private void b2_Click(object sender, EventArgs e)
        {
            textBoxRes.Text += "2";
        }

        private void b3_Click(object sender, EventArgs e)
        {
            textBoxRes.Text += "3";
        }

        private void b0_Click(object sender, EventArgs e)
        {
            textBoxRes.Text += "0";
        }

        private void bP_Click(object sender, EventArgs e)
        {
            textBoxRes.Text += ".";
        }

        private void bIgual_Click(object sender, EventArgs e)
        {
            v2 = Convert.ToDecimal(textBoxRes.Text, CultureInfo.InvariantCulture);

            if (operacao == "Soma") 
            {
                textBoxRes.Text = Convert.ToString(v1 + v2);
            }

            else if(operacao == "Sub") 
            {
                textBoxRes.Text = Convert.ToString(v1 - v2);
            }

            else if(operacao == "Multi")
            {
                textBoxRes.Text = Convert.ToString(v1 * v2);
            }

            else 
            {
                textBoxRes.Text = Convert.ToString(v1 / v2);
            }
        }

        private void bSub_Click(object sender, EventArgs e)
        {
            v1 = Convert.ToDecimal(textBoxRes.Text, CultureInfo.InvariantCulture);
            textBoxRes.Text = "";
            operacao = "Sub";
            lbl_op.Text = "-";
        }

        private void bMulti_Click(object sender, EventArgs e)
        {
            v1 = Convert.ToDecimal(textBoxRes.Text, CultureInfo.InvariantCulture);
            textBoxRes.Text = "";
            operacao = "Multi";
            lbl_op.Text = "x";
        }

        private void bDiv_Click(object sender, EventArgs e)
        {
            v1 = Convert.ToDecimal(textBoxRes.Text, CultureInfo.InvariantCulture);
            textBoxRes.Text = "";
            operacao = "Div";
            lbl_op.Text = "/";
        }

        private void bCE_Click(object sender, EventArgs e) //Limpar tudo
        {
            v1 = 0;
            v2 = 0;
            lbl_op.Text = "";
            textBoxRes.Text = "";
        }

        private void bC_Click(object sender, EventArgs e) //Ele limpar o numero digitao por ultimo
        {
            textBoxRes.Text = "";
        }

        private void bSoma_Click(object sender, EventArgs e)
        {
            v1 = Convert.ToDecimal(textBoxRes.Text, CultureInfo.InvariantCulture);
            textBoxRes.Text = "";
            operacao = "Soma";
            lbl_op.Text = "+"; 
        }
    }
}
